import {BounceLoader} from "react-spinners";

export default function Preloader() {
  return (
    <BounceLoader speedMultiplier={2} color={'#348DFA'} />
  );
}