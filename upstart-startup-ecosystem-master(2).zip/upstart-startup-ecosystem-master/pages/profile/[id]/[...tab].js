import ProfilePage from "../../profile";

export default function ProfileAbout() {
  return <ProfilePage />;
}