import ProfilePage from "../profile";

export default function Profile() {
  return <ProfilePage />;
}
